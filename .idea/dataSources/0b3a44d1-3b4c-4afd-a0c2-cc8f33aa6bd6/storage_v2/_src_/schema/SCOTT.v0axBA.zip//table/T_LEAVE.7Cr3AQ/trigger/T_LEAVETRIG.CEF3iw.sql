create trigger T_LEAVETRIG
  before insert
  on T_LEAVE
  for each row
  BEGIN
    SELECT SEQ_T_LEAVE.nextval INTO :new.L_ID FROM dual;
  end;
/

