create trigger T_DEPARTMENTTRIG
  before insert
  on T_DEPARTMENT
  for each row
  BEGIN
    SELECT SEQ_T_DEPARTMENT.nextval INTO :new.D_ID FROM dual;
  end;
/

