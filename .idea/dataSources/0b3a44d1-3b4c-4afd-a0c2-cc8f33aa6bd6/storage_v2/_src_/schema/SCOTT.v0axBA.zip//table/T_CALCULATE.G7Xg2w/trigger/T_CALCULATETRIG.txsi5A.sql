create trigger T_CALCULATETRIG
  before insert
  on T_CALCULATE
  for each row
  BEGIN
    SELECT SEQ_T_CALCULATE.nextval INTO :new.C_ID FROM dual;
  end;
/

