create trigger T_GCSTATETRIG
  before insert
  on T_GCSTATE
  for each row
  BEGIN
    SELECT SEQ_T_GCSTATE.nextval INTO :new.GC_ID FROM dual;
  end;
/

