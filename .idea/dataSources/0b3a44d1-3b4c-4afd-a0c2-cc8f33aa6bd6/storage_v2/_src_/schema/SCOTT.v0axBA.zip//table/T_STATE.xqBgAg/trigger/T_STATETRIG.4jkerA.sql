create trigger T_STATETRIG
  before insert
  on T_STATE
  for each row
  BEGIN
    SELECT SEQ_T_STATE.nextval INTO :new.S_ID FROM dual;
  end;
/

