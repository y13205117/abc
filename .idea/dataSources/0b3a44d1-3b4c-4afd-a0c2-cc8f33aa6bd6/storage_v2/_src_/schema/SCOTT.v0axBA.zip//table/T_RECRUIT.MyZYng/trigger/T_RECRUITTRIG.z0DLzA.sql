create trigger T_RECRUITTRIG
  before insert
  on T_RECRUIT
  for each row
  BEGIN
    SELECT SEQ_T_RECRUIT.nextval INTO :new.R_ID FROM dual;
  end;
/

