create trigger T_INFORMATIONTRIG
  before insert
  on T_INFORMATION
  for each row
  BEGIN
    SELECT SEQ_T_INFORMATION.nextval INTO :new.I_ID FROM dual;
  end;
/

