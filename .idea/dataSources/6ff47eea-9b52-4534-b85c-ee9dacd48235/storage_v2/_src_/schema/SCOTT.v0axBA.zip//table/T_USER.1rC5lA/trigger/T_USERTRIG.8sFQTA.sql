create trigger T_USERTRIG
  before insert
  on T_USER
  for each row
  BEGIN
    SELECT SEQ_T_USER.nextval INTO :new.U_ID FROM dual;
  end;
/

