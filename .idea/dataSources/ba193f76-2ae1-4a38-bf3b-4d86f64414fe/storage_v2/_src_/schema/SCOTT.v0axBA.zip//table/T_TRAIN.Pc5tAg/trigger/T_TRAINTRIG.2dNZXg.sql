create trigger T_TRAINTRIG
  before insert
  on T_TRAIN
  for each row
  BEGIN
    SELECT SEQ_T_TRAIN.nextval INTO :new.T_ID FROM dual;
  end;
/

