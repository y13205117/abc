create trigger T_JOBTRIG
  before insert
  on T_JOB
  for each row
  BEGIN
    SELECT SEQ_T_JOB.nextval INTO :new.J_ID FROM dual;
  end;
/

