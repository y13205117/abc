create trigger T_MEMBERSHOWCVTRIG
  before insert
  on T_MEMBERSHOWCV
  for each row
  BEGIN
    SELECT SEQ_T_MEMBERSHOWCV.nextval INTO :new.M_ID FROM dual;
  end;
/

