create trigger T_GATECARDTRIG
  before insert
  on T_GATECARD
  for each row
  BEGIN
    SELECT SEQ_T_GATECARD.nextval INTO :new.G_ID FROM dual;
  end;
/

