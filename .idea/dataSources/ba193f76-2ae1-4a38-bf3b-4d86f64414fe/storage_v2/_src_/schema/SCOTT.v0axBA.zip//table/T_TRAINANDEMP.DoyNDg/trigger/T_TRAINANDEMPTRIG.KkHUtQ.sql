create trigger T_TRAINANDEMPTRIG
  before insert
  on T_TRAINANDEMP
  for each row
  BEGIN
    SELECT SEQ_T_TRAINANDEMP.nextval INTO :new.TAE_ID FROM dual;
  end;
/

