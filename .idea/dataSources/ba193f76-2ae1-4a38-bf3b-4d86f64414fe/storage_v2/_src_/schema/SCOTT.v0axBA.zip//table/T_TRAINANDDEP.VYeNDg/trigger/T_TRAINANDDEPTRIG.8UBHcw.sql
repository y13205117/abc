create trigger T_TRAINANDDEPTRIG
  before insert
  on T_TRAINANDDEP
  for each row
  BEGIN
    SELECT SEQ_T_TRAINANDDEP.nextval INTO :new.TAD_ID FROM dual;
  end;
/

