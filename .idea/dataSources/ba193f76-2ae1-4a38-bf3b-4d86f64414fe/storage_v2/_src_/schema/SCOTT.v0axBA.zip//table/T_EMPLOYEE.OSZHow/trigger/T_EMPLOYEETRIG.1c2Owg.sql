create trigger T_EMPLOYEETRIG
  before insert
  on T_EMPLOYEE
  for each row
  BEGIN
    SELECT SEQ_T_EMPLOYEE.nextval INTO :new.E_ID FROM dual;
  end;
/

