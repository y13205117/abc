create trigger T_AWARDRECORDTRIG
  before insert
  on T_AWARDRECORD
  for each row
  BEGIN
    SELECT SEQ_T_AWARDRECORD.nextval INTO :new.A_ID FROM dual;
  end;
/

