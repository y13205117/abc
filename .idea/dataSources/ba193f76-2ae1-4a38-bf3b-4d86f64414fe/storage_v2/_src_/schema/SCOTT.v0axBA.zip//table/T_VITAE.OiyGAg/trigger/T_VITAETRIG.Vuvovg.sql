create trigger T_VITAETRIG
  before insert
  on T_VITAE
  for each row
  BEGIN
    SELECT SEQ_T_VITAE.nextval INTO :new.V_ID FROM dual;
  end;
/

